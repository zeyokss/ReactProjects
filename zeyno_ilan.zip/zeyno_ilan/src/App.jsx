import React, { useState } from 'react';
import FilterSidebar from './Components/FilterSideBar/FilterSideBar';
import Navbar from './Components/Navbar/Navbar';
import Cards from './Components/Cards/Cards';
import './index.css';



const App = () => {
  const [selectedFilters, setSelectedFilters] = useState({
    brand: [],
    fuelType: [],
    transmission: [],
  });

  const handleApplyFilters = (filters) => {
    setSelectedFilters({
      brand: filters.selectedBrands,
      fuelType: filters.selectedFuelTypes,
      transmission: filters.selectedTransmissions,
    });
  };
  

  
  return (
    <div>
      <Navbar />
      <FilterSidebar onApplyFilters={handleApplyFilters} />
      <Cards selectedFilters={selectedFilters} />
    </div>
  );
};

export default App;
