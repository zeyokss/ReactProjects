import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import CardMedia from '@mui/material/CardMedia';
import IconButton from '@mui/material/IconButton';
import StarIcon from '@mui/icons-material/Star';
import { Button } from '@mui/material';
import InfoIcon from '@mui/icons-material/Info';
import PropTypes from 'prop-types';

export default function Cards({ selectedFilters }) {
  const [carData, setCarData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  console.log(filteredData);

  useEffect(() => {
    // Fetch data from JSON file
    fetch('/carData.json')
      .then((response) => response.json())
      .then((data) => {
        setCarData(data.cards);
        setFilteredData(data.cards); // Initially set all data
      })
      .catch((error) => console.error('Error fetching data:', error));
  }, []);

  useEffect(() => {
    // Filter data based on selected filters
    const filtered = carData.filter((car) => {
      const matchesBrand = selectedFilters.brand.length ? selectedFilters.brand.includes(car.brand) : true;
      const matchesFuel = selectedFilters.fuelType.length ? selectedFilters.fuelType.includes(car.fuelType) : true;
      const matchesTransmission = selectedFilters.transmission.length ? selectedFilters.transmission.includes(car.transmission) : true;
      return matchesBrand && matchesFuel && matchesTransmission;
    });
    setFilteredData(filtered);
  }, [carData, selectedFilters]);

  return (
    <Box sx={{ position: 'absolute', width: 930, top: 128, left: 720, backgroundColor: '#E7EAE8', display: 'flex', flexDirection: 'column', gap: 2 }}>
      {/* If no cars match the filters, show a message */}
      {filteredData.length === 0 ? (
        <Typography sx={{ textAlign: 'center', fontFamily: 'Inter', fontSize: 16, fontWeight: 600, color: '#317B52' }}>
          Aranılan kriterlere uygun araba bulunamadı
        </Typography>
      ) : (
        filteredData.map((car, index) => (
          <Card key={index} sx={{ minWidth: 275, height: 137.75, position: 'relative' }}>
            <Box display="flex" flexDirection="row">
              <CardMedia>
                <img style={{ width: 206, height: 128.75, borderRadius: 4 }} src={car.image} alt={car.title} />
              </CardMedia>
              <CardContent sx={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <Box display="flex" flexDirection="row" alignItems="center" gap={1}>
                  <Typography sx={{ fontFamily: 'Inter', fontWeight: 600, fontSize: 15, color: '#317B52' }}>
                    {car.title}
                  </Typography>
                  <IconButton sx={{ width: 16, height: 16, padding: 0 }} aria-label="star">
                    <StarIcon sx={{ fontSize: 16 }} />
                  </IconButton>
                </Box>
                <Typography sx={{ fontFamily: 'Inter', fontWeight: 400, fontSize: 10, color: '#6A7670', marginTop: 1 }}>
                  {car.description}
                </Typography>
                <Box component="ul" sx={{ display: 'flex', flexDirection: 'row', alignItems: 'center', gap: 1, marginTop: 5, listStyle: 'none' }}>
                  {car.details.map((item, i) => (
                    <Box
                      component="li"
                      key={i}
                      sx={{
                        fontFamily: 'Inter',
                        fontSize: '12.69px',
                        fontWeight: 400,
                        color: '#6A7670',
                        ...(i !== 0 && { borderLeft: '1px solid #E7EAE8', paddingLeft: '7px' })
                      }}
                    >
                      {item}
                    </Box>
                  ))}
                </Box>
                <Button sx={{ backgroundColor: '#09AA59', color: '#FFFFFF', width: 112, height: 36, fontFamily: 'Inter', borderRadius: 15, marginLeft: 70, marginTop: -4 }}>
                  Hemen Al
                </Button>
                <Box sx={{ position: 'absolute', top: '13%', left: '86.5%', textAlign: 'center' }}>
                  <Box display="flex" flexDirection="row" alignItems="center" justifyContent="center" gap={1}>
                    <Typography sx={{ fontFamily: 'Inter', fontWeight: 400, fontSize: 8.91, color: '#99A59F' }}>
                      Satış Fiyatı/TL
                    </Typography>
                    <InfoIcon sx={{ fontSize: 'small', color: '#99A59F' }} />
                  </Box>
                  <Typography sx={{ fontFamily: 'Inter', fontSize: 13.13, fontWeight: 700, color: '#231F20', marginTop: '2px' }}>
                    {car.price}
                  </Typography>
                </Box>
              </CardContent>
            </Box>
          </Card>
        ))
      )}
    </Box>
  );
}

Cards.propTypes = {
  selectedFilters: PropTypes.shape({
    brand: PropTypes.arrayOf(PropTypes.string),
    fuelType: PropTypes.arrayOf(PropTypes.string),
    transmission: PropTypes.arrayOf(PropTypes.string),
  }),
};
