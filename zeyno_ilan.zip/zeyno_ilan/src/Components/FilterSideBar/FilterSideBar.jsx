import React, { useState, useEffect } from 'react';
import { Grid, Typography, Checkbox, FormControlLabel, FormGroup, TextField, Box, Button } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import PropTypes from 'prop-types';

const theme = createTheme({
  typography: {
    fontFamily: 'Inter',
    fontWeight: 400,
    fontSize: 12.8,
    color: '#424D46',
  },
});

const FiltersSidebar = ({ onApplyFilters }) => {
  const [filterData, setFilterData] = useState(null);
  const [selectedBrands, setSelectedBrands] = useState({});
  const [selectedFuelTypes, setSelectedFuelTypes] = useState({});
  const [selectedTransmissions, setSelectedTransmissions] = useState({});
  const [priceRange, setPriceRange] = useState({ min: '', max: '' });
  const [kmRange, setKmRange] = useState({ min: '', max: '' });

  useEffect(() => {
    fetch('/filtersData.json')
      .then((response) => response.json())
      .then((data) => {
        setFilterData(data);
        setSelectedBrands(data.brands.reduce((acc, brand) => ({ ...acc, [brand]: false }), {}));
        setSelectedFuelTypes(data.fuelTypes.reduce((acc, fuelType) => ({ ...acc, [fuelType]: false }), {}));
        setSelectedTransmissions(data.transmissions.reduce((acc, transmission) => ({ ...acc, [transmission]: false }), {}));
        setPriceRange(data.priceRange);
        setKmRange(data.kmRange);
      })
      .catch((error) => console.error('Error fetching filter data:', error));
  }, []);

  const handleCheckboxChange = (type, item) => {
    
    if (item === 'Tümü') {
        if (type === 'brand') {
            setSelectedBrands(prev => {
                const allSelected = Object.values(prev).every(value => value);
                const updated = Object.keys(prev).reduce((acc, key) => {
                    acc[key] = !allSelected; 
                    return acc;
                }, {});
                return updated;
            });
        } else if (type === 'fuelType') {
            setSelectedFuelTypes(prev => {
                const allSelected = Object.values(prev).every(value => value);
                const updated = Object.keys(prev).reduce((acc, key) => {
                    acc[key] = !allSelected; 
                    return acc;
                }, {});
                return updated;
            });
        } else if (type === 'transmission') {
            setSelectedTransmissions(prev => {
                const allSelected = Object.values(prev).every(value => value);
                const updated = Object.keys(prev).reduce((acc, key) => {
                    acc[key] = !allSelected; 
                    return acc;
                }, {});
                return updated;
            });
        }
    } else {
        
        if (type === 'brand') {
            setSelectedBrands(prev => ({ ...prev, [item]: !prev[item] }));
        } else if (type === 'fuelType') {
            setSelectedFuelTypes(prev => ({ ...prev, [item]: !prev[item] }));
        } else if (type === 'transmission') {
            setSelectedTransmissions(prev => ({ ...prev, [item]: !prev[item] }));
        }
    }
};


  /*const handleRangeChange = (rangeType, field, value) => {
    if (rangeType === 'price') {
      setPriceRange(prev => ({ ...prev, [field]: value }));
    } else if (rangeType === 'km') {
      setKmRange(prev => ({ ...prev, [field]: value }));
    }
  };*/

  const applyFilters = () => {
    const filters = {
      selectedBrands: Object.keys(selectedBrands).filter(brand => selectedBrands[brand]),
      selectedFuelTypes: Object.keys(selectedFuelTypes).filter(fuelType => selectedFuelTypes[fuelType]),
      selectedTransmissions: Object.keys(selectedTransmissions).filter(transmission => selectedTransmissions[transmission]),
      priceRange,
      kmRange,
    };

    onApplyFilters(filters);
  };

  return (
    <ThemeProvider theme={theme}>
      <div style={{
        position: 'absolute',
        top: '70px',
        left: '394px',
        height: '100vh',
        width: '300px',
        padding: '20px',
        borderRadius: '4px',
        border: '1px solid #E7EAE8',
        backgroundColor: '#F4F6F5',
        overflowY: 'auto',
      }}>
        <Grid container direction="column" spacing={3} style={{ maxWidth: '300px' }}>
          {/* Brand Filter */}
          <Grid item>
            <Typography sx={{ fontWeight: 600, fontSize: '13.89px', color: '#536259' }}>Marka</Typography>
            <FormGroup style={{ maxHeight: '300px', overflowY: 'auto' }}>
              {filterData && filterData.brands.map((brand) => (
                <FormControlLabel
                  control={<Checkbox checked={selectedBrands[brand] || false} onChange={() => handleCheckboxChange('brand', brand)} sx={{ '&.Mui-checked': { color: '#4caf50' } }} />}
                  label={brand}
                  key={brand}
                />
              ))}
            </FormGroup>
          </Grid>

          {/* Fuel Type Filter */}
          <Grid item>
            <Typography sx={{ fontWeight: 600, fontSize: '13.89px', color: '#536259' }}>Yakıt Tipi</Typography>
            <FormGroup style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {filterData && filterData.fuelTypes.map((fuelType) => (
                <FormControlLabel
                  control={<Checkbox checked={selectedFuelTypes[fuelType] || false} onChange={() => handleCheckboxChange('fuelType', fuelType)} sx={{ '&.Mui-checked': { color: '#4caf50' } }} />}
                  label={fuelType}
                  key={fuelType}
                />
              ))}
            </FormGroup>
          </Grid>

          {/* Transmission Type Filter */}
          <Grid item>
            <Typography sx={{ fontWeight: 600, fontSize: '13.89px', color: '#536259' }}>Vites Tipi</Typography>
            <FormGroup style={{ maxHeight: '200px', overflowY: 'auto' }}>
              {filterData && filterData.transmissions.map((transmission) => (
                <FormControlLabel
                  control={<Checkbox checked={selectedTransmissions[transmission] || false} onChange={() => handleCheckboxChange('transmission', transmission)} sx={{ '&.Mui-checked': { color: '#4caf50' } }} />}
                  label={transmission}
                  key={transmission}
                />
              ))}
            </FormGroup>
          </Grid>

          {/* Price Range Filter */}
          <Grid item>
            <Typography sx={{ fontWeight: 600, fontSize: '13.89px', color: '#536259' }}>Fiyat</Typography>
            <Box display="flex" gap={2}>
              <TextField
                label="Min"
                type="number"
                name="min"
                value={priceRange.min}
                /*onChange={(e) => handleRangeChange('price', 'min', e.target.value)}*/
                variant="outlined"
                size="small"
                fullWidth
              />
              <TextField
                label="Max"
                type="number"
                name="max"
                value={priceRange.max}
                /*onChange={(e) => handleRangeChange('price', 'max', e.target.value)}*/
                variant="outlined"
                size="small"
                fullWidth
              />
            </Box>
          </Grid>

          {/* Km Range Filter */}
          <Grid item>
            <Typography sx={{ fontWeight: 600, fontSize: '13.89px', color: '#536259' }}>Km</Typography>
            <Box display="flex" gap={2}>
              <TextField
                label="Min"
                type="number"
                name="min"
                value={kmRange.min}
                //onChange={(e) => handleRangeChange('km', 'min', e.target.value)}
                variant="outlined"
                size="small"
                fullWidth
              />
              <TextField
                label="Max"
                type="number"
                name="max"
                value={kmRange.max}
                //onChange={(e) => handleRangeChange('km', 'max', e.target.value)}
                variant="outlined"
                size="small"
                fullWidth
              />
            </Box>
          </Grid>

          {/* Apply Filters Button */}
          <Grid item>
            <Button
              sx={{
                marginLeft: '100px',
                top: '20px',
                fontFamily: 'Inter',
                backgroundColor: '#09AA59',
                color: '#FFFFFF',
                '&:hover': { backgroundColor: '#08a95c' },
              }}
              variant="contained"
              onClick={applyFilters}
            >
              FİLTRELE
            </Button>
          </Grid>
        </Grid>
      </div>
    </ThemeProvider>
  );
};

FiltersSidebar.propTypes = {
  onApplyFilters: PropTypes.func.isRequired,
};

export default FiltersSidebar;
