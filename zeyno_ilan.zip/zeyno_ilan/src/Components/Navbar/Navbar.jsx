/*import React from 'react'*/
import './Navbar.css'
import logo from '../.././assets/ikinciyeni-logo.svg'
import logo2 from '../.././assets/anadolu-grubu.jpeg'



const Navbar = () => {
  return (
    <header className="header">
        <div className='logos-container'>
            <a href="" className='ikinciyeniLogo'><img src={logo} alt="İkinci Yeni Logo"/></a>
            <a href="" className='logo2'><img src={logo2} alt="Anadolu Grubu Logo"/></a>
        </div>

        
        <nav className="navbar">
            <a href="">Açık Artırma</a>
            <a href="">Araç Al</a>
            <a href="">Araç Sat</a>
            <a href="">Filonu Sat</a>
            <a href="">Ekspertiz Al</a>
            <a href="" >Lojistik Al <span></span></a>
            
            <button className='login-button'>Giriş Yap</button>
        </nav>
    </header>
  )
}

export default Navbar