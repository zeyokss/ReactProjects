import React from 'react';
import TodoList from './component/TodoList';

function App() {
    return (
        <div className="App" style={{ padding: '20px', maxWidth: '500px', margin: '0 auto',backgroundColor: '#deeaee' }}>
            <TodoList />
        </div>
    );
}

export default App;
