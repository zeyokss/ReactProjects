//item görevin bilgilerini içeriyor (id,text,completed)

const TodoItem = ({ item, onDelete, onEdit, onToggle })/*destructuring*/ => {
    let priorityClass = '';     //props nesnesini alır ve içindeki özellikleri (item, onDelete, vb.) ayrı ayrı parametreler olarak ayırır.
    
    

    return (
        <li className={`task-item ${item.priority}`} style={{ display: 'flex', alignItems: 'center', marginBottom: '10px',fontFamily: '' }}>
            <input id="checkedTask"
                type="checkbox" 
                checked={item.completed} 
                onChange={() => onToggle(item.id)} 
                style={{ marginRight: '10px' }}
            />
            <span 
                style={{ 
                    textDecoration: item.completed ? 'line-through' : 'none',
                    color: item.completed ? 'purple' : 'white',
                    flex: 1 
                }}
            >
                {item.text}
            </span>
            <span style={{ color: 'grey', marginLeft: '10px', marginRight: '10px' }}>{item.dueDate}</span> 
            <button onClick={() => onEdit(item.id)} style={{ marginRight: '5px' }}>Edit</button>
            <button onClick={() => onDelete(item.id)}>Delete</button>
        </li>
    );
};

export default TodoItem;
