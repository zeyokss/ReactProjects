import React, { useState } from 'react';
import TodoItem from './TodoItem';
import '../App.css' ;



//TODO
const TodoList = () => {
    const [tasks, setTasks] = useState([/*initial value*/]);//tüm görevlerin listesi
    const [newTask, setNewTask] = useState('');//kullanıcının girdiği yeni görev metni
    const [editingTaskId, setEditingTaskId] = useState(null);
    const [editingText, setEditingText] = useState('');
    const [newTaskDate, setNewTaskDate] = useState(''); 
    const [newTaskPriority, setNewTaskPriority] = useState('');
    const [filterText,setFilterText] =  useState('');
    const [filteredTasks, setFilteredTasks] = useState(tasks);
    const priorityOrder = {
        "high-priority": 1,
        "medium-priority": 2,
        "low-priority": 3,
    };
    

    //use effect
    //virtual dom
    //vite,dosyalar
    const sortTasksByPriority = (tasks) => {
        return [...tasks].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
    };
    
    const addTask = () => {
        if (newTask.trim() && newTaskPriority ) {//Kullanıcı boşluk bırakıp sadece " " gibi bir şey girdiğinde, bu görev listeye eklenmesin.
            const updatedTasks = [
                ...tasks, 
                { id: Date.now(), text: newTask, completed: false,dueDate: newTaskDate, priority: newTaskPriority }
                
                
            ];
            setTasks(sortTasksByPriority(updatedTasks))
            setNewTask('');
            setNewTaskDate('');
            setNewTaskPriority('');
        } else {
            alert("Please choose a valid option!"); 
            
        }
    };

    const deleteTask = (id) => {
        setTasks(tasks.filter(task => task.id !== id));//belirtilen idye sahip task hariç tüm taskler filtrelenir
    };

    
    const toggleTask = (id) => {//checkbox kontrolü
        setTasks(
            tasks.map(task =>
                task.id === id ? { ...task, completed: !task.completed } : task 
            )
        );
    };

    const startEditing = (id) => {
        const taskToEdit = tasks.find(task => task.id === id);
        if(taskToEdit.completed){
            alert("This task is completed. You can't edit it.")
            return;
        }
           
        
        setEditingTaskId(id);
        setEditingText(taskToEdit.text);
    };

    const saveEdit = () => {
        setTasks(
            tasks.map(task =>
                task.id === editingTaskId ? { ...task, text: editingText } : task
            )
        );
        setEditingTaskId(null);//düzenleme durumunu sıfırlamak için kullanıldı
        
    };

   

    return (
        <div>
            <div className='header'>
            <h1>To-Do List</h1>
                <input type="text"
                    value={filterText}
                    onChange={(e) => setFilterText(e.target.value)}
                    placeholder='Search'

                />
                {/* *{!} input al texte göre display etsin seçenek olunca her şeyi filtreleyemiyosun */}
            </div>
            

            <div className="entry-container">
                <input 
                    
                    type="text" 
                    value={newTask} 
                    onChange={(e) => setNewTask(e.target.value)} 
                    placeholder="Add a new task"
                />
                <input 
                    type="date" 
                    value={newTaskDate} 
                    onChange={(e) => setNewTaskDate(e.target.value)} 
                    placeholder="Select due date"
                />
                <select 
                    value={newTaskPriority} 
                    onChange={(e) => setNewTaskPriority(e.target.value)} 
                    className="priority-select"
                >   
                    <option value="">Select Priority</option>
                    <option value="low-priority">Low Priority</option>
                    <option value="medium-priority">Medium Priority</option>
                    <option value="high-priority">High Priority</option>
                   
                </select>
                <button onClick={addTask}>Add</button>
                
            </div>

<ul className='tasksList'>
    {tasks
        .filter(task => 
            task.text.toLowerCase().includes(filterText.toLowerCase())
        ) 
        .map(task =>
            task.id === editingTaskId ? (
                <li key={task.id} style={{ display: 'flex', alignItems: 'center', backgroundColor: 'lightgray'}}>
                    <input 
                        type="text" 
                        value={editingText} 
                        onChange={(e) => setEditingText(e.target.value)} 
                        style={{ flex: 1 }}
                    />
                    <button onClick={saveEdit}>Save</button>
                </li>
            ) : (
                <TodoItem 
                    key={task.id} 
                    item={task} 
                    onDelete={deleteTask} 
                    onEdit={startEditing} 
                    onToggle={toggleTask} 
                />
            )
        )}
</ul>

        </div>
    );
};

export default TodoList;
